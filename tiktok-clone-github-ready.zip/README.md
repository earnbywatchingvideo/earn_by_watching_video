# TikTok Clone Web App

This is a basic TikTok-style web application built with React + Vite.

## Features
- Infinite scroll video feed
- Video upload
- Profile system
- Cloudinary image/video hosting
- Supabase backend

## Setup

1. Clone this repository
2. Copy `.env.example` to `.env` and fill in your credentials
3. Run `npm install`
4. Run `npm run dev` to start the development server
